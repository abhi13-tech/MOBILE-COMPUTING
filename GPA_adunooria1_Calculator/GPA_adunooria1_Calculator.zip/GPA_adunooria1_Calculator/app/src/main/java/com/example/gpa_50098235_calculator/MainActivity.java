package com.example.gpa_50098235_calculator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Introduce a delay of 2 seconds (2000 milliseconds)
        int delayMillis = 3000;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Create an Intent to start GPA_Main
                Intent intent = new Intent(MainActivity.this, GPA_Main.class);

                // Start GPA_Main
                startActivity(intent);

                // Finish MainActivity to prevent going back to it from GPA_Main
                finish();
            }
        }, delayMillis);
    }
}

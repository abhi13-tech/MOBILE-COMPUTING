package com.example.gpa_50098235_calculator;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.*;

import androidx.appcompat.app.AppCompatActivity;

public class GPA_Main extends AppCompatActivity {
    private EditText[] editTexts;
    private Button buttonComputeGPA;
    private TextView textViewGPA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpa_main);
        editTexts = new EditText[]{
                findViewById(R.id.editTextGrade1),
                findViewById(R.id.editTextGrade2),
                findViewById(R.id.editTextGrade3),
                findViewById(R.id.editTextGrade4),
                findViewById(R.id.editTextGrade5)
        };
        buttonComputeGPA = findViewById(R.id.buttonComputeGPA);
        textViewGPA = findViewById(R.id.textViewGPA);
        buttonComputeGPA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonComputeGPA.getText().equals("Compute GPA")) {
                    computeGPA(view);
                } else {
                    clearForm();
                }
            }
        });
    }

        private void computeGPA(View view) {
        double totalCredits = 5;
        double totalGradePoints = 0;
        boolean allFieldsFilled = true;
        StringBuilder errorMessage = new StringBuilder();
        for (int i = 0; i < editTexts.length; i++) {
            EditText editText = editTexts[i];
            String gradeText = editText.getText().toString().trim();
            if (gradeText.isEmpty()) {
                allFieldsFilled = false;
                errorMessage.append("Enter a grade for Course ").append(i + 1).append("\n");
            } else {
                double grade = Double.parseDouble(gradeText);
                totalGradePoints += grade;
            }
        }
        if (!allFieldsFilled) {
            showToast(errorMessage.toString());
            return;
        }
        for (EditText editText : editTexts) {
            editText.setError(null);
        }
        double gpa = totalGradePoints / totalCredits;
        textViewGPA.setText("GPA: " + gpa);
        textViewGPA.setTextColor(Color.BLACK);
        textViewGPA.setTextSize(25);
        textViewGPA.setTypeface(null, Typeface.BOLD);
        textViewGPA.setGravity(Gravity.CENTER);
        buttonComputeGPA.setText("Clear Form");
        int backgroundColor;
        if (gpa < 0 || gpa > 100) {
            showToast("Invalid GPA");
            return;
        } else if (gpa < 60) {
            backgroundColor = Color.RED;
        } else if (gpa >= 61 && gpa <= 79) {
            backgroundColor = Color.YELLOW;
        } else {
            backgroundColor = Color.GREEN;
        }
        findViewById(R.id.rootLayout).setBackgroundColor(backgroundColor);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void clearForm() {
        for (EditText editText : editTexts) {
            editText.getText().clear();
        }
        textViewGPA.setText("GPA: ");
        buttonComputeGPA.setText("Compute GPA");
        textViewGPA.setTextSize(18);
        textViewGPA.setTypeface(null, Typeface.NORMAL);
        findViewById(R.id.rootLayout).setBackgroundColor(Color.TRANSPARENT);
    }
}
